#include "stm32f4xx_hal.h"              // Keil::Device:STM32Cube HAL:Common
#include "cmsis_os.h"                   // ARM::CMSIS:RTOS:Keil RTX
#include "RTE_Components.h"             // Component selection

int counter1, counter2, counter3, counter4, counter5;
osThreadId tid_job1;
osThreadId tid_job2;
osMutexId mut_A;
osMutexDef(mut_A);

void job1 (void const *arg) { //First thread
while (1) { // loop forever
// higher priority job
osDelay(10);
counter1++;
osDelay(1000);

osMutexWait(mut_A,osWaitForever);
osDelay(10000);
counter3++; // update the counter
osMutexRelease(mut_A);
}

}
void job2 (void const *arg) { //Second thread
while (1) { // loop forever
counter2++; 
osMutexWait(mut_A,osWaitForever);	
osDelay(10000);
//osThreadSetPriority (tid_job2, osPriorityAboveNormal);
//executes 	// update the counter
osDelay(5000);
counter3++;
//osThreadSetPriority (tid_job2, osPriorityNormal);
osMutexRelease(mut_A);	
}
}

osThreadDef (job1, osPriorityHigh , 1, 0); //thread object �job1�
osThreadDef (job2, osPriorityAboveNormal , 1, 0); //thread object �job2�
int main (void) {

osKernelInitialize (); // setup kernel 
tid_job1 = osThreadCreate (osThread(job1), NULL); // create and add thread �job1� to Thread List
tid_job2 = osThreadCreate (osThread(job2), NULL); // create and add thread �job2� to Thread List
mut_A = osMutexCreate(osMutex(mut_A));
osKernelStart (); // start kernel
	while(1);
}